﻿namespace Telephony
{
    public interface IBrawseable
    {
        public string Brawse(string url);
    }
}
