﻿namespace Telephony
{
    interface ICallable
    {
        public string Call(string number);
    }
}
